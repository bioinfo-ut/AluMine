/*
 * Genome Mapper
 *
 * Text Algorithms, 2013/2014
 *
 * Authors: Maarja Lepamets, Fanny-Dhelia Pajuste
 */

#include <stdio.h>
#include <string.h>
#include <malloc.h>

#include "utils.h"

#define debug 0

typedef unsigned u32;

/*
 * Per seed location function
 *
 * n          - index of current seed
 * locations  - list of all locations in genome
 * pos        - per seed array of indices into locations
 * m          - step between seeds
 *
 * returns    - the match location of given seed (from locations array)
 */

unsigned long long loc (unsigned long long n, unsigned long long *locations, unsigned long long *pos, unsigned int m) {
	return locations[pos[n]] - n * m;
}

/* Find all candidate locations of given query
 *
 * query      - query sequence (read)
 * words      - pointer to sorted array of all words in genome
 * nwords     - number of words (and starts)
 * starts     - starting indices of given word
 * locations  - list of all locations in genome
 * nlocations - number of distinct locations
 * wordlen    - word length
 * m          - step between seeds
 * seeds      - array where seeds will be written (has to be big enough to fit all)
 * candidates - array where candidate locations will be written
 * max_candidates - the size of candidate array
 * cutoff     - minimum ratio of confirming seeds to consider given position as candidate
 *
 * returns    - number of candidate locations
 */

u32 find_candidates (queryblock *qb, unsigned long long *words, unsigned long long nwords, unsigned long long *starts, unsigned long long *locations, unsigned long long nlocations,
	unsigned wordlen, unsigned m, unsigned long long *seeds, unsigned max_candidates, unsigned mmis) {
	/* Per seed arrays */
	/* pos is index into locations array we are currently processing */
	static unsigned long long *pos = NULL;
	/* end is the end index (one past last) of givevn seed locations */
	static unsigned long long *end = NULL;
	static unsigned int possize = 0;
	unsigned int nseeds, i, ncandidates;
	unsigned long long minloc;
	int minn;
	int cutoff;

	nseeds = get_seeds (qb->query, words, nwords, wordlen, m, seeds);
	cutoff = (wordlen % m == 0) ? nseeds - (wordlen / m) * mmis : nseeds - (wordlen / m + 1) * mmis;
	if (cutoff <= 0) cutoff = 1;
	if (debug) fprintf(stderr, "Siide: %u, cutoff: %d\n", nseeds, cutoff);

	if (nseeds == 0) {
		if (debug) fprintf (stderr, "Query %s gave 0 seeds\n", qb->query);
		return 0;
	}

	if (debug > 1) {
		fprintf (stderr, "Query %s gave %d seeds\n", qb->query, nseeds);
		if (debug > 2) {
			for (i = 0; i < nseeds; i++) {
				if (seeds[i] == nwords) continue;
				u32 j;
				fprintf (stderr, "Seed %d index %llu word %llu sequence ", i, seeds[i], words[seeds[i]]);
				for (j = 0; j < wordlen; j++) {
					static const char *n = "ACGT";
					fprintf (stderr, "%c", n[(words[seeds[i]] >> (wordlen - 1 - j)) & 3]);
				}
				fprintf (stderr, "\n");
			}
		}
	}

	/* Ensure we have enough room for pos and count arrays */
	if (nseeds > possize) {
		possize = nseeds;
		pos = (unsigned long long *) realloc (pos, possize * sizeof (unsigned long long));
		end = (unsigned long long *) realloc (end, possize * sizeof (unsigned long long));
	}

	/* Initialize per seed arrays */
	for (i = 0; i < nseeds; i++) {
		if (seeds[i] == nwords) continue;
		pos[i] = starts[seeds[i]];
		if (seeds[i] < (nwords - 1)) {
			end[i] = starts[seeds[i] + 1];
		} else {
			end[i] = nlocations;
		}
	}

	/* Main iteration */
	ncandidates = 0;
	while (ncandidates < max_candidates) {
		int nfound;
		/* Find minimum n */
		minn = -1;
		minloc = 0xffffffffffffffff;
		for (i = 0; i < nseeds; i++) {
			if (seeds[i] == nwords) continue;
			if (pos[i] < end[i]) {
				unsigned long long l = loc (i, locations, pos, m);
				if ((minloc == 0xffffffffffffffff) || (l < minloc)) {
					minn = i;
					minloc = l;
				}
			}
		}
		if (minn < 0) {
			/* No more locations for any seed */
			break;
		}
		if (debug > 1) fprintf (stderr, "Found match at %llu\n", minloc);
		/* Get all seeds that confirm minloc */
		/* We increase pos values here as well because we do not need them until next iteration */
		candidate cand;
		cand.loc = minloc;
		cand.mmis = 0;
		cand.length = (unsigned) strlen(qb->query);
		cand.nregions = 1;
		cand.reg[0].loc = minloc;
		cand.reg[0].qstart = 0;
		cand.reg[0].qend = cand.length;
		nfound = 0;
		if (debug > 1) fprintf (stderr, "Seeds: ");
		for (i = 0; i < nseeds; i++) {
			if (seeds[i] == nwords) continue;
			if (pos[i] < end[i]) {
				u32 l = loc (i, locations, pos, m);
				int delta = (long long) l - (long long) minloc;
				/* Is delta close enough */
				if ((delta >= -(int) mmis) && (delta <= (int) mmis)) {
					unsigned int sloc;
					/* This seed confirms given location */
					nfound += 1;
					/* Update query region list */
					sloc = m * i;
					if ((sloc > cand.reg[cand.nregions - 1].qstart) && ((sloc + wordlen) < cand.reg[cand.nregions - 1].qend)) {
						/* Split region */
						cand.reg[cand.nregions - 1].qend = sloc;
						if (cand.nregions < MAX_REGIONS) {
							cand.nregions += 1;
							cand.reg[cand.nregions - 1].loc = minloc + sloc + wordlen;
							cand.reg[cand.nregions - 1].qstart = sloc + wordlen;
							cand.reg[cand.nregions - 1].qend = cand.length;
						}
					} else if (sloc > cand.reg[cand.nregions - 1].qstart) {
						/* Clip region end */
						cand.reg[cand.nregions - 1].qend = sloc;
					} else if ((sloc + wordlen) < cand.reg[cand.nregions - 1].qend) {
						/* Clip region start */
						cand.reg[cand.nregions - 1].qstart = sloc + wordlen;
						cand.reg[cand.nregions - 1].loc = minloc + sloc + wordlen;
					}
					/* Advance pos value */
					pos[i] += 1;
					if (debug > 1) fprintf (stderr, "%u ", i);
				}
			}
		}
		if (debug > 0) fprintf (stderr, "\n");
		if ((cand.reg[cand.nregions - 1].qstart >= cand.length) || (cand.reg[cand.nregions - 1].qend <= 0)) {
			/* Region became empty */
			cand.nregions -= 1;
		}
		if (nfound >= cutoff) {
			qb->candidates[ncandidates++] = cand;
			if (debug > 1) {
				fprintf (stderr, "Found candidate location %llu\n", minloc);
			}
		}
	}

	return ncandidates;
}

/*
 * Get list of seed indices (in words array)
 *
 * query      - search query
 * words      - pointer to sorted array of all words in genome
 * nwords     - number of words (and starts)
 * wordlen    - word length
 * m          - step between seeds
 * seeds      - array where seeds will be written (has to be big enough to fit all)
 *
 * returns    - number of seeds
 */

unsigned int
get_seeds (const char *query, unsigned long long *words, unsigned long long nwords, unsigned int wordlen, unsigned int m, unsigned long long *seeds) {
	static int *nucl = NULL;
	u32 qlen, pos, idx;

	/* Initialize nucleotide lookup table */
	if (nucl == NULL) {
		int i;
		nucl = (int *) malloc (256 * sizeof (int));
		for (i = 0; i < 256; i++) nucl[i] = -1;
		nucl['a'] = nucl['A'] = 0;
		nucl['c'] = nucl['C'] = 1;
		nucl['g'] = nucl['G'] = 2;
		nucl['t'] = nucl['T'] = 3;
	}

	qlen = strlen (query);
	pos = 0;
	idx = 0;
	while (pos < (qlen - wordlen)) {
		u32 word = 0;
		u32 i, index;
		for (i = 0; i < wordlen; i++) {
			if (nucl[(unsigned char) query[pos + i]] < 0) break;
			word <<= 2;
			word |= nucl[(unsigned char) query[pos + i]];
		}
		/* If we did not complete full iteration there was invalid nucleotide */
		if (i == wordlen) {
		  /* Find index of given word */
		  index = search_word (word, words, nwords);
		} else {
		  index = nwords;
		}
		seeds[idx++] = index;
		pos += m;
	}

	return idx;
}

/*
 * Binary search
 *
 * word       - current word
 * words      - pointer to sorted array of all words in genome
 * nwords     - number of words (and starts)
 *
 * returns    - the index of current word or nwords if not found
 */

unsigned long long
search_word (unsigned long long word, const unsigned long long *words, unsigned long long nwords) {
	unsigned long long s, e;
	/* Do binary search */
	s = 0;
	e = nwords - 1;
	while ((e - s) > 1) {
		unsigned long long m = (s + e) / 2;
		if (words[m] == word) {
			return m;
		} else if (words[m] < word) {
			s = m;
		} else {
			e = m;
		}
	}
	return nwords;
}
