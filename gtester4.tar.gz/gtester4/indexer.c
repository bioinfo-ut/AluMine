/*
 * Genome Indexer
 * (using radix sort)
 *
 * Text Algorithms, 2013/2014
 *
 * Author: Maarja Lepamets
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>

#include "utils.h"

int debug = 0;

/* reading in the genome in FastA format */
/* if name is not NULL it will be assigned a copy of sequence name */
unsigned long long readfastafile(const char *filename, wordtable *table, unsigned long long loc, char **name);

/* fills the table with words and their locations */
/* if name is not NULL it will be assigned a copy of sequence name */
unsigned long long fillwordtable(const char *data, wordtable *table, struct stat st, unsigned long long loc, char **name);

/* mask has as many 1's as the wordlength is */
unsigned long long createmask (unsigned int wordlength);

/* wrapper for in-place radix sort */
void sortwords(wordtable *table);

/* */
unsigned long long countunique (wordtable *table);

/* */
void findstartpositions(wordtable *table);

/* */
void sortlocations(wordtable *table);

/* for combining two sorted lists of words (with locations) */
void combineindices(wordtable *table, wordtable *other);

/* */
void writetoindex(wordtable *table, const char *outputname, sequences seqinfo);

int main (int argc, const char *argv[])
{
	int wordlen;
	int i, inputbeg = -1, inputend = -1;
	unsigned long long location;
	const char *outputname;
	sequences seqinfo;
	wordtable tables[2];
	wordtable *table = &tables[0];
	wordtable *temptable = &tables[1];
	char ofsname[256];
	FILE *ofs;

	memset(table, 0, sizeof(wordtable));
	memset(temptable, 0, sizeof(wordtable));

	/* default value */
	wordlen = 16;
	outputname = "output";

	/* parsing commandline arguments */
	for (i = 1; i < argc; ++i) {
		if (!strcmp(argv[i], "-i")) {
			if (i >= argc) break;
			/* get the locations of the input files */
			inputbeg = ++i;
			while (i < argc - 1 && argv[i + 1][0] != '-') {
				++i;
			}
			inputend = i;
		} else if (!strcmp(argv[i], "-d")) {
			debug += 1;
		} else if (!strcmp(argv[i], "-o")) {
			outputname = argv[i + 1];
			++i;
		} else if (!strcmp(argv[i], "-n")) {
			char *e;
			wordlen = strtol (argv[i + 1], &e, 10);
			if (*e != 0) {
				fprintf(stderr, "Invalid input: %s!\n", argv[i + 1]);
				exit(1);
			}
			++i;
		} else {
			fprintf(stderr, "Unknown argument: %s\n", argv[i]);
			exit(1);
		}
	}

	/* checking the parameter */
	if (wordlen > 32) {
		fprintf(stderr, "Seed size too large!\n");
		exit(1);
	}
	if (inputbeg == -1) {
		fprintf(stderr, "No input files given!\n");
		exit(1);
	}

	seqinfo.seq_name = (char **) malloc((inputend - inputbeg + 1) * sizeof(const char *));
	seqinfo.start_pos = (unsigned long long *) malloc ((inputend - inputbeg + 1) * sizeof (unsigned long long));
	seqinfo.n = inputend - inputbeg + 1;

	/* work-flow */
	location = 0;
	sprintf(ofsname, "%s.names", outputname);
	ofs = fopen (ofsname, "w");
	for (i = inputbeg; i <= inputend; ++i) { /* iteration over the input file parameters */
		char *seqname;
		unsigned long long currentloc;
		char *p;

		if (debug > 0) fprintf (stderr, "Reading: %s...\n", argv[i]);

		temptable->wordlength = wordlen;
		if (i > inputbeg) {
			location += 10000;
		}
		currentloc = location;
		seqinfo.seq_name[i - inputbeg] = (char *) argv[i];
		seqinfo.start_pos[i - inputbeg] = location;

		location = readfastafile (argv[i], temptable, location, &seqname);

		if (temptable->nwords == 0) continue;
		sortwords (temptable);
		findstartpositions (temptable);
		sortlocations (temptable);
		if (i > inputbeg) {
			combineindices (table, temptable);
		} else {
			*table = *temptable;
		}
		
		/* Debug */
		if (debug > 0) {
			unsigned int i, j;
			unsigned long long idx[3];
			fprintf (stderr, "Sequence: %s (%llu)\n", seqname, currentloc);
			idx[0] = 0;
			idx[1] = table->nwords / 2;
			idx[2] = table->nwords - 1;
			for (i = 0; i < 3; i++) {
				char c[256];
				unsigned long long word = table->words[idx[i]];
				unsigned long long start = table->starts[idx[i]];
				unsigned long long nloc = (idx[i] == table->nwords) ? table->nloc - start : table->locations[table->starts[idx[i] + 1]] - start;
				word2string (c, word, table->wordlength);
				fprintf (stderr, "Position %llu Word %llu %s start %llu\n", idx[i], word, c, start);
				if (debug > 1) {
					for (j = 0; j < nloc; j++) {
						fprintf (stderr, "    %llu\n", table->locations[start + j]);
					}
				}
			}
		}

		/* Clean up temporary table */
		memset (temptable, 0, sizeof (wordtable));
		
		/* Write sequence start position to locations file */
		for (p = seqname; *p; ++p) {
			if (*p <= ' ') {
				*p = 0;
				break;
			}
		}
		fprintf (ofs, "%s %s %llu\n", seqname, argv[i], currentloc);
	}
	fclose (ofs);

	if (debug > 2) {
		unsigned int i, j;
		char seq[64];
		for (i = 0; i < table->nwords - 1; ++i) {
			word2string (seq, table->words[i], table->wordlength);
			fprintf (stderr, "järjestus %s, start %llu\n", seq, table->starts[i]);
			for (j = table->starts[i]; j < table->starts[i + 1]; ++j) {
				fprintf(stderr, "asukohad: %llu ", table->locations[j]);
			}
			fprintf (stderr, "\n");
		}
		word2string (seq, table->words[i], table->wordlength);
		fprintf (stderr, "järjestus %s, start %llu\n", seq, table->starts[i]);
		for (j = table->starts[i]; j < table->nloc; ++j) {
			fprintf (stderr, "asukohad: %llu ", table->locations[j]);
		}
		fprintf (stderr, "\n");
	}

	writetoindex(table, outputname, seqinfo);
	fprintf(stdout, "Done!\n");
	return 0;
}

unsigned long long
readfastafile(const char *filename, wordtable *table, unsigned long long locprev, char **name)
{
	struct stat st;				/* file statistics */
	int status, handle;
	const char *data;
	unsigned long long loc;

	/* memory-mapping a file */
	status = stat(filename, &st);
	if (status < 0) {
		fprintf (stderr, "Cannot get the statistics of file %s!\n", filename);
		exit (1);
	}
	handle = open(filename, O_RDONLY);
	if (handle < 0) {
		fprintf (stderr, "Cannot open file %s!\n", filename);
		exit (1);
	}
	data = (const char *) mmap(NULL, st.st_size, PROT_READ, MAP_SHARED, handle, 0);
	if (data == (const char *) -1) {
		fprintf (stderr, "Cannot memory-map file %s!\n", filename);
		exit (1);
	}
	close(handle);

	if ((unsigned long long) st.st_size > table->nword_slots) {
		table->nword_slots = st.st_size;
		table->nloc_slots = st.st_size;
		table->words = (unsigned long long *) realloc(table->words, table->nword_slots * sizeof (unsigned long long));
		table->locations = (unsigned long long *) realloc(table->locations, table->nloc_slots * sizeof (unsigned long long));
	}
	loc = fillwordtable (data, table, st, locprev, name);

	munmap((void *) data, st.st_size);
	return loc;
}

unsigned long long
fillwordtable(const char *data, wordtable *table, struct stat st, unsigned long long locprev, char **name)
{
	unsigned long long word, min, max;
	unsigned long long mask;
	unsigned long long cursor;
	int m, wordlength;
	int isheader = 0;
	off_t i;
	/* Initiqalized to suppress warning */
	off_t namestart = 0;
	max = 0;
	min = ~max;

	wordlength = table->wordlength;
	mask = createmask(wordlength);
	if (debug > 0) fprintf (stderr, "Mask: %llx\n", mask);
	word = 0;
	cursor = locprev;
	m = 0;

	/* find the unsigned integer corresponding to a word with a given length */
	for (i = 0; i < st.st_size; ++i) {
		if (data[i] == '>') {
			isheader = 1;
			namestart = i + 1;
			if (i != 0) {
				fprintf(stderr, "Only one FastA sequence per file is allowed!\n");
				exit(1);
			}
		}
		if (isheader) {
			if (data[i] == '\n') {
				isheader = 0;
				if (name) {
					*name = (char *) malloc (i - namestart);
					memcpy (*name, data + namestart, i - namestart);
					(*name)[i - namestart] = 0;
				}
			}
		} else {
			if (data[i] < 'A') {
				continue;
			} else if (strchr(alphabet, data[i]) == NULL) {
				word = 0;
				m = 0;
				cursor += 1;
				continue;
			}
			word <<= 2;
			word |= getnuclvalue(data[i]);
			m += 1;
			if (m > wordlength) {
				word &= mask;
				m = wordlength;
			}
			if (m == wordlength) {
				table->words[table->nwords] = word;
				table->locations[table->nloc] = cursor + 1 - table->wordlength;
				table->nwords += 1;
				table->nloc += 1;
				if (debug > 0) {
					if (word < min) min = word;
					if (word > max) max = word;
				}
				/* location += 1; */
			}
			cursor += 1;
		}

	}
	if (debug > 0) {
		char c[256];
		word2string (c, min, wordlength);
		fprintf (stderr, "Min: %llu %s\n", min, c);
		word2string (c, max, wordlength);
		fprintf (stderr, "Max: %llu %s\n", max, c);
	}
	/*printf("alguses nloc %u\n", table->nloc);*/
	return cursor;
}

unsigned long long
createmask (unsigned int wordlength)
{
	unsigned int i;
	unsigned long long mask = 0;
	for (i = 0; i < wordlength; ++i) {
		mask = (mask << 2) | 3;
	}
	return mask;
}

void
sortwords (wordtable *table)
{
	int firstshift = 0, i;
	if (table->nwords == 0) return;

	/* calculate the number of shifted positions for making radix sort faster (no need to sort digits that are all zeros)*/
	for (i = 8; i < table->wordlength * 2; i+= 8) firstshift += 8;

	hybridInPlaceRadixSort256 (table->words, table->words + table->nwords, table->locations, firstshift);
}

unsigned long long
countunique (wordtable *table)
{
	unsigned long long i, count;
	count = 0;
	for (i = 0; i < table->nwords; ++i) {
		if (i == 0 || table->words[i] != table->words[i - 1])
			++count;
	}
	return count;
}

void
findstartpositions (wordtable *table)
{
	unsigned long long ri, wi, count, nunique;

	if (table->nwords == 0) return;
	nunique = countunique (table);

	if (nunique > table->nstart_slots) {
		table->nstart_slots = nunique;
		table->starts = (unsigned long long *) realloc (table->starts, table->nstart_slots * sizeof (unsigned long long));
	}

	wi = 1;
	count = 1;
	table->starts[0] = 0;
	for (ri = 1; ri < table->nwords; ++ri) {
		if (table->words[ri] == table->words[ri - 1]) {
			count += 1;
		} else {
			table->words[wi - 1] = table->words[ri - 1];
			table->starts[wi] = count;
			count += 1;
			++wi;
		}
	}
	table->words[wi - 1] = table->words[ri - 1];
	table->nwords = nunique;
	table->nstarts = nunique;
}

void
sortlocations (wordtable *table)
{
	unsigned long long i;
	for (i = 0; i < table->nwords - 1; ++i) {
		hybridInPlaceRadixSort256 (table->locations + table->starts[i], table->locations + table->starts[i + 1], NULL, 56);
	}
	hybridInPlaceRadixSort256 (table->locations + table->starts[i], table->locations + table->nloc, NULL, 56);
}

void
combineindices (wordtable *table, wordtable *other)
{
	long long i, j, k, l;
	int n1, n2;
	unsigned long long count, location_pos, count1 = 0, count2 = 0;

	if (table->nloc + other->nloc > table->nloc_slots) {
		table->nloc_slots = table->nloc + other->nloc;
		table->locations = (unsigned long long *) realloc (table->locations, table->nloc_slots * sizeof (unsigned long long));
	}
	location_pos = table->nloc + other->nloc - 1;

	j = 0;
	count = 0;
	for (i = 0; i < (long long) other->nwords; ) {
		if (j < (long long) table->nwords && table->words[j] == other->words[i]) {
			++i;
			++j;
		} else if (j < (long long) table->nwords && table->words[j] < other->words[i]) {
			++j;
		} else {
			++i;
			++count;
		}
	}

	if (table->nwords + count > table->nword_slots) {
		table->nword_slots = table->nwords + count;
		table->words = (unsigned long long *) realloc(table->words, table->nword_slots * sizeof (unsigned long long));
	}
	if (table->nstarts + count > table->nstart_slots) {
		table->nstart_slots = table->nwords + count;
		table->starts = (unsigned long long *) realloc(table->starts, table->nstart_slots * sizeof (unsigned long long));
	}

	i = other->nwords - 1;
	j = table->nwords - 1;
	n1 = table->nloc - table->starts[j];
	n2 = other->nloc - other->starts[i];
	for (k = table->nwords + count - 1; k >= 0; --k) {
		if (i >= 0 && j >= 0 && table->words[j] == other->words[i]) {
			for (l = n2 - 1; l >= 0; --l) {
				table->locations[location_pos] = other->locations[other->starts[i] + l];
				location_pos--;
				count1++;
			}
			for (l = n1 - 1; l >= 0; --l) {
				table->locations[location_pos] = table->locations[table->starts[j] + l];
				location_pos--;
				count1++;
			}
			n1 = (j > 0) ? table->starts[j] - table->starts[j - 1] : 0;
			n2 = (i > 0) ? other->starts[i] - other->starts[i - 1] : 0;
			table->words[k] = table->words[j];
			table->starts[k] = location_pos + 1;
			--j; --i;
		} else if ((i < 0) || (j >= 0 && table->words[j] > other->words[i])) {
			for (l = n1 - 1; l >= 0; --l) {
				table->locations[location_pos] = table->locations[table->starts[j] + l];
				location_pos--;
				count1++;
			}
			n1 = (j > 0) ? table->starts[j] - table->starts[j - 1] : 0;
			table->words[k] = table->words[j];
			table->starts[k] = location_pos + 1;
			--j;

		} else {
			for (l = n2 - 1; l >= 0; --l) {
				table->locations[location_pos] = other->locations[other->starts[i] + l];
				location_pos--;
				count2++;
			}
			n2 = (i > 0) ? other->starts[i] - other->starts[i - 1] : 0;
			table->words[k] = other->words[i];
			table->starts[k] = location_pos + 1;
			--i;
		}
	}
	table->nwords += count;
	table->nstarts += count;
	table->nloc += other->nloc;
}

void writetoindex(wordtable *table, const char *outputname, sequences seqinfo)
{
	unsigned long long i;
	char fname[256];
	FILE *f;
	info h;
	if (table->nwords == 0) return;

	h.wordsize = table->wordlength;
	h.nwords = table->nwords;
	h.nlocations = table->nloc;
	h.seqs = seqinfo;

	if (debug) {
		long long i;
		for (i = 0; i < seqinfo.n; ++i) {
			printf("%s %llu\n", seqinfo.seq_name[i], seqinfo.start_pos[i]);
		}
	}

	printf("%s %llu\n", h.seqs.seq_name[0], h.seqs.start_pos[0]);

	sprintf(fname, "%s_%d.index", outputname, table->wordlength);
	f = fopen(fname, "w");
	fwrite(&h, sizeof(info), 1, f);

	for (i = 0; i < table->nwords; ++i) {
		fwrite(&table->words[i], sizeof(table->words[i]), 1, f);
	}
	for (i = 0; i < table->nstarts; ++i) {
		fwrite(&table->starts[i], sizeof(table->starts[i]), 1, f);
	}
	for (i = 0; i < table->nloc; ++i) {
		fwrite(&table->locations[i], sizeof(table->locations[i]), 1, f);
	}
	return;
}
