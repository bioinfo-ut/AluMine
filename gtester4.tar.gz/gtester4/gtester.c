/*
 * Genome Tester
 *
 * Text Algorithms, 2013/2014
 *
 * Authors: Lauris Kaplinski, Maarja Lepamets, Fanny-Dhelia Pajuste
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>

#include "utils.h"

#define MAX_READ_LENGTH 1000
#define MAX_CANDIDATES 10000

int debug = 0;

typedef struct _chromosome {
	char *name;
	char *filename;
	unsigned long long start;
	unsigned long long length;
	char *sequence;
} Chromosome;

unsigned int printseq = 0;
unsigned int len3p = 0;
unsigned int len5p = 0;

int editDistanceMiddle (char* sg, char* sr);

void printindex(const char *data);
const char* filemmap(const char *filename, struct stat *st);

static void lookup_string (const char *query, int wordlen, const unsigned long long *words, const unsigned long long *starts, unsigned long long nwords, const unsigned long long *locations, unsigned long long nloc, Chromosome *chr, unsigned nchr);
static void lookup_word (unsigned long long word, int wordlen, const unsigned long long *words, const unsigned long long *starts, unsigned long long nwords, const unsigned long long *locations, unsigned long long nloc, Chromosome *chr, unsigned nchr, unsigned int reverse);

static void print_chromosome_info (unsigned long long word, unsigned int wordlen, unsigned long long location, Chromosome *chr, unsigned int nchr, unsigned int reverse);

int main (int argc, const char *argv[])
{
	int i;
	int mmis = 0;
	const char *queryfile = NULL;
	const char *query = NULL;
	const char *indexfile = NULL, *namefile = NULL;
	struct stat stindex;
	const char *outputname = "output";
	const char *ind;
	info *h;
	Chromosome chr[256];
	int nchr = 0;
	const unsigned char *chrmap;
	const unsigned long long *words, *starts, *locations;

	for (i = 1; i < argc; ++i) {
		if (!strcmp(argv[i], "-d")) {
			debug += 1;
		} else if (!strcmp(argv[i], "-i")) {
			if (!argv[i + 1]) break;
			indexfile = argv[i + 1];
			++i;
		} else if (!strcmp(argv[i], "-g")) {
			if (!argv[i + 1]) break;
			namefile = argv[i + 1];
			++i;
		} else if (!strcmp(argv[i], "-q")) {
			if (!argv[i + 1]) break;
			query = argv[i + 1];
			++i;
		} else if (!strcmp(argv[i], "-f")) {
			if (!argv[i + 1]) break;
			queryfile = argv[i + 1];
			++i;
		} else if (!strcmp(argv[i], "-o")) {
			outputname = argv[i + 1];
			++i;
		} else if (!strcmp(argv[i], "-mm")) {
			char *e;
			mmis = strtol (argv[i + 1], &e, 10);
			if (*e != 0) {
				fprintf(stderr, "Invalid input: %s!\n", argv[i + 1]);
				exit(1);
			}
			++i;
		} else if (!strcmp(argv[i], "-5p")) {
			char *e;
			len5p = strtol (argv[i + 1], &e, 10);
			if (*e != 0) {
				fprintf(stderr, "Invalid input: %s!\n", argv[i + 1]);
				exit(1);
			}
			++i;
		} else if (!strcmp(argv[i], "-3p")) {
			char *e;
			len3p = strtol (argv[i + 1], &e, 10);
			if (*e != 0) {
				fprintf(stderr, "Invalid input: %s!\n", argv[i + 1]);
				exit(1);
			}
			++i;
		} else {
			fprintf(stderr, "Unknown argument: %s\n", argv[i]);
			exit(1);
		}
	}

	/* checking parameters */
	if (!indexfile || (!query && !queryfile)) {
		fprintf(stderr, "Some input is missing!\n");
		exit(1);
	}
	if (mmis < 0) {
		fprintf(stderr, "Number of mismatches must be positive!\n");
		exit(1);
	}
	if (!namefile) {
		fprintf(stderr, "Genome files are needed!\n");
		exit(1);
	}

	if (len3p > 64) len3p = 64;
	if (len5p > 64) len5p = 64;
	if ((len3p > 0) || (len5p > 0)) printseq = 1;

	/* Parse chromosome description file */
	chrmap = (const unsigned char *) filemmap (namefile, &stindex);
	if (chrmap) {
		unsigned s = 0;
		if (debug > 0) fprintf (stderr, "Chromosome locations:\n");
		while (s < stindex.st_size) {
			unsigned ns, ne, fs, fe, ps, pe;
			ns = ne = s;
			while (chrmap[ne] > ' ') {
				ne += 1;
			}
			fs = ne;
			while ((fs < stindex.st_size) && (chrmap[fs] <= ' ')) fs += 1;
			fe = fs;
			while (chrmap[fe] > ' ') fe += 1;
			ps = fe;
			while ((ps < stindex.st_size) && (chrmap[ps] <= ' ')) ps += 1;
			pe = ps;
			while (chrmap[pe] > ' ') pe += 1;
			if ((ne > ns) && (fe > fs) && (pe > ps)) {
				/* fprintf (stderr, "%u %u %u %u %u %u\n", ns, ne, fs, fe, ps, pe); */
				chr[nchr].name = (char *) malloc (ne - ns + 1);
				memcpy (chr[nchr].name, chrmap + ns, ne - ns + 1);
				chr[nchr].name[ne - ns] = 0;
				chr[nchr].filename = (char *) malloc (fe - fs + 1);
				memcpy (chr[nchr].filename, chrmap + fs, fe - fs + 1);
				chr[nchr].filename[fe - fs] = 0;
				chr[nchr].start = strtoll ((const char *) chrmap + ps, NULL, 10);
				chr[nchr].length = 0;
				chr[nchr].sequence = NULL;
				if (debug > 0) fprintf (stderr, "Chromosome %s at %s position %llu\n", chr[nchr].name, chr[nchr].filename, chr[nchr].start);
				nchr += 1;
			}
			s = pe;
			while ((s < stindex.st_size) && (chrmap[s] <= ' ')) s += 1;
		}
	}
	
	ind = filemmap (indexfile, &stindex);
	h = (info *) ind;

	words = (const unsigned long long *) (ind + sizeof (info));
	starts = (const unsigned long long *) (ind + sizeof (info) + h->nwords * sizeof (unsigned long long));
	locations = (const unsigned long long *) (ind + sizeof (info) + h->nwords * sizeof (unsigned long long) + h->nwords * sizeof (unsigned long long));
                                         
 	if (query) {
		lookup_string (query, h->wordsize, words, starts, h->nwords, locations, h->nlocations, chr, nchr);
	} else {
		const char *qmap, *p, *e;
		char q[256];
		unsigned int idx, len;
		idx = 0;
		qmap = filemmap (queryfile, &stindex);
		p = qmap;
		e = p + stindex.st_size;
		while (p < e) {
			const char *s;
			while ((*p < 'A') && (p < e)) p += 1;
			s = p;
			while ((*p >= 'A') && (p < e)) p += 1;
			len = p - s;
			if (len >= 8) {
				if (len > 255) len = 255;
				memcpy (q, s, len);
				q[len] = 0;
				fprintf (stdout, "Query %d %s\n", idx++, q);
				lookup_string (q, h->wordsize, words, starts, h->nwords, locations, h->nlocations, chr, nchr);
			}
		}
	}

	return 0;
}

static void
lookup_string (const char *query, int wordlen, const unsigned long long *words, const unsigned long long *starts, unsigned long long nwords, const unsigned long long *locations, unsigned long long nloc, Chromosome *chr, unsigned nchr)
{
	unsigned long long word;

	if (string2word (&word, query, wordlen)) {
		lookup_word (word, wordlen, words, starts, nwords, locations, nloc, chr, nchr, 0);
		word = getreversecomplement (word, wordlen);
		lookup_word (word, wordlen, words, starts, nwords, locations, nloc, chr, nchr, 1);
	} else {
		fprintf (stderr, "Invalid query: %s\n", query);
	}
}

static void
lookup_word (unsigned long long word, int wordlen, const unsigned long long *words, const unsigned long long *starts, unsigned long long nwords, const unsigned long long *locations, unsigned long long nloc, Chromosome *chr, unsigned nchr, unsigned int reverse)
{
	unsigned long long index;
	/* Find index of given word */
	index = search_word (word, words, nwords);
	if (index < nwords) {
		unsigned long long nlocs, i;
		if (index < (nwords - 1)) {
			nlocs = starts[index + 1] - starts[index];
		} else {
			nlocs = nwords - starts[index];
		}
		if (debug > 0) fprintf (stdout, "Found %llu locations\n", nlocs);
		for (i = 0; i < nlocs; i++) {
			unsigned long long loc = locations[starts[index] + i];
			print_chromosome_info (word, wordlen, loc, chr, nchr, reverse);
		}
	} else {
		if (debug) fprintf (stdout, "Not found\n");
	}
}

/* fixme: Update qstart */

/* Return si of last query match or -1 if distance > nmm */

int
fill_table (int *d, const char *query, int qlen, const char *seq, int slen, unsigned *qstart, unsigned int nmm)
{
	int qi, si, dist, lasts;
	/* Fill first column */
	for (si = 0; si <= slen; si++) {
		d[si * (qlen + 1) + 0] = (si < 2 * (int) *qstart) ? 0 : si - 2 * (int) *qstart;
	}
	/* Fill first row */
	for (qi = 1; qi <= qlen; qi++) {
		d[qi] = 99;
	}
	for (qi = 1; qi <= qlen; qi++) {
		int best = 999;
		for (si = 1; si <= slen; si++) {
			unsigned dl, dtl, dt;
			dl = d[si * (qlen + 1) + qi - 1] + 1;
			dtl = d[(si - 1) * (qlen + 1) + qi - 1];
			if ((qi < qlen) && (si < slen) && (query[qi] != seq[si])) dtl += 1;
			dt = d[(si - 1) * (qlen + 1) + qi] + 1;
			d[si * (qlen + 1) + qi] = ((dl < dtl) && (dl < dt)) ? dl : ((dt < dl) && (dt < dtl)) ? dt : dtl;
			if (d[si * (qlen + 1) + qi] > best) best = d[si * (qlen + 1) + qi];
		}
		if (best > (int) nmm) return -1;
	}
	dist = 99;
	lasts = 0;
	for (si = 0; si <= slen; si++) {
		if (d[si * (qlen + 1) + qlen] < dist) {
			dist = d[si * (qlen + 1) + qlen];
			lasts = si;
		}
	}
	return lasts;
} 

void
find_alignment (int *d, const char *query, int qlen, const char *seq, int slen, char *s, char *q, int lasts)
{
	int qi, si;
	unsigned sp, qp, i;
	/* Print alignment */
	sp = 0;
	qp = 0;
	qi = qlen - 1;
	si = slen - 1;
	while (si >= lasts) {
		s[sp++] = seq[si--];
		q[qp++] = '-';
	}
	while ((qi >= 0) || (si >= 0)) {
		unsigned dl, dtl, dt;
		dl = (qi > 0) ? d[si * (qlen + 1) + qi - 1] : 99;
		dtl = ((qi > 0) && (si > 0)) ? d[(si - 1) * (qlen + 1) + qi - 1] : 99;
		dt = (si > 0) ? d[(si - 1) * (qlen + 1) + qi] : 99;
			if (qi < 0) {
				/* End of query */
				s[sp++] = seq[si--];
				q[qp++] = '-';
			} else if (si < 0) {
				/* End of sequence */
				s[sp++] = '-';
				q[qp++] = query[qi--];
			} else if (qi == 0) {
                              	s[sp++] = seq[si--];
                              	q[qp++] = query[qi--];
			} else if (si == 0) {
				s[sp++] = seq[si--];
				q[qp++] = '-';
			} else if ((dtl <= dl) && (dtl <= dt)) {
				/* Match or ungapped mismatch */
				s[sp++] = seq[si--];
				q[qp++] = query[qi--];
			} else if ((dl <= dtl) && (dl <= dt)) {
				/* Gap in sequence */
				s[sp++] = '-';
				q[qp++] = query[qi--];
			} else {
				/* Gap in query */
				s[sp++] = seq[si--];
				q[qp++] = '-';
			}
		}
		for (i = 0; i < qp / 2; i++) {
			char t = q[i];
			q[i] = q[qp - 1 - i];
			q[qp - 1 - i] = t;
		}
		for (i = 0; i < sp / 2; i++) {
			char t = s[i];
			s[i] = s[sp - 1 - i];
			s[sp - 1 - i] = t;
		}
		s[sp] = 0;
		q[qp] = 0;
}

void
printindex (const char *data)
{
	unsigned long long *words, *starts, *locations;
	unsigned long long nwords, nlocations;
	unsigned wordlength;
	info *h;
	unsigned long long i, j;
	char c[256];

	h = (info *) data;
	wordlength = h->wordsize;
	nwords = h->nwords;
	nlocations = h->nlocations;

	words = (unsigned long long *)(data + sizeof (info));
	starts = (unsigned long long *)(data + sizeof (info) + nwords * sizeof (unsigned long long));
	locations = (unsigned long long *)(data + sizeof (info) + nwords * sizeof (unsigned long long) + nwords * sizeof (unsigned long long));

	for (i = 0; i < nwords - 1; ++i) {
		word2string (c, words[i], wordlength);
		fprintf (stdout, "%s\t%llu\n", c, starts[i]);
		for (j = starts[i]; j < starts[i + 1]; ++j) {
			fprintf(stdout, "%llu ", locations[j]);
		}
		fprintf(stdout, "\n");
	}
	word2string (c, words[i], wordlength);
	fprintf(stdout, "%s\t%llu\n", c, starts[i]);
	for (j = starts[i]; j < nlocations; ++j) {
		fprintf(stdout, "%llu ", locations[j]);
	}
	fprintf(stdout, "\n");

}

const char* filemmap(const char *filename, struct stat *st)
{
	int status, handle;
	const char *data;

	/* memory-mapping a file */
	status = stat(filename, st);
	if (status < 0) {
		fprintf (stderr, "Cannot get the statistics of file %s!\n", filename);
		exit (1);
	}
	handle = open(filename, O_RDONLY);
	if (handle < 0) {
		fprintf (stderr, "Cannot open file %s!\n", filename);
		exit (1);
	}
	data = (const char *) mmap(NULL, st->st_size, PROT_READ, MAP_SHARED, handle, 0);
	if (data == (const char *) -1) {
		fprintf (stderr, "Cannot memory-map file %s!\n", filename);
		exit (1);
	}
	close(handle);

	return data;
}

static unsigned int
ensure_chromosome_loaded (Chromosome *chr)
{
	/* Load chromosome if not already loaded */
	if (chr->sequence == NULL) {
		struct stat st;
		unsigned d, s, header;
		const char *seq = filemmap (chr->filename, &st);
		if (seq == NULL) {
			fprintf (stderr, "Cannot mmap %s\n", chr->filename);
			exit (1);
		}
		chr->sequence = (char *) malloc (st.st_size);
		d = 0;
		header = 0;
		for (s = 0; s < st.st_size; s++) {
			if (seq[s] == '>') header = 1;
			if (header) {
				if (seq[s] == '\n') header = 0;
			} else {
				if (seq[s] >= 'A') chr->sequence[d++] = seq[s];
			}
		}
		chr->length = d;
		munmap ((void *) seq, st.st_size);
	}
	return chr->sequence != NULL;
}

static void
print_chromosome_info (unsigned long long word, unsigned int wordlen, unsigned long long location, Chromosome *chr, unsigned int nchr, unsigned int reverse)
{
	unsigned i;
	char seq[256];
	/* Find chromosome */
	for (i = 1; i < nchr; i++) {
		if (location < chr[i].start) break;
	}
	i -= 1;
	/* Print location */
	fprintf (stdout, "%d\t%s\t%s\t%llu\n", i, chr[i].name, (reverse) ? "-" : "+", location - chr[i].start);
	if (printseq) {
		/* word2string (seq, word, wordlen); */
		/* fprintf (stdout, "%s\n", seq); */
		if (ensure_chromosome_loaded (&chr[i])) {
			unsigned long long start;
			unsigned int len;
			start = location - chr[i].start;
			start -= (reverse) ? len3p : len5p;
			len = len5p + wordlen + len3p;
			memcpy (seq, chr[i].sequence + start, len);
			seq[len] = 0;
			if (debug > 2) fprintf (stderr, "Start: %llu\n", start);
			if (reverse) {
				char rev[256];
				getreversecomplementstr (rev, seq, len);
				rev[len] = 0;
				fprintf (stdout, "%s\n", rev);
			} else {
				fprintf (stdout, "%s\n", seq);
			}
		}
	}
}
